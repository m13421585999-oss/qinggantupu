# Watercolor course theme assets

These raster files are intentionally text-free. The recitation map text, pinyin, marks and prosody curve are rendered programmatically by SVG/React for precision.
