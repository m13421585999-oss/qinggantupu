# Stage 9.30 · 清洁安装说明

```bash
cd /Users/mcf/Desktop
rm -rf recitation-map-editor
unzip recitation-map-editor-stage9-30-a4-pinyin-vertical-center-clean.zip
cd recitation-map-editor/app
npm install
npm run dev
```
