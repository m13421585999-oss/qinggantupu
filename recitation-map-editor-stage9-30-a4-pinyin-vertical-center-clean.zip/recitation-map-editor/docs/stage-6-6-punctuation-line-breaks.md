# 第六阶段 v6.6：标点优先自动换行

## 目标

在 v6.4 的语义分行基础上，增加“标点优先”的分行逻辑。文稿超过一行容量时，不再只按 10 个 token 或 display_group 边界处理，而是优先回看前面是否存在标点，并在标点之后换行。

## 换行优先级

自动换行优先级如下：

1. 标点边界优先：`,`、`，`、`。`、`！`、`？`、`；`、`：`、`、` 等标点保留在上一行末尾。
2. 停顿边界其次：`/`、`//`、`///` 保留在上一行末尾。
3. display_group 词组边界再次：避免把“幸福”“周游世界”等词组拆开。
4. 兜底硬切：只有当单个 display_group 本身超过一行容量时，才允许拆开。

## 示例

原句：

```text
从明天起，做一个幸福的人。
```

如果一行容量不足，系统优先在逗号后换行：

```text
从 明 天 起，/
做 一 个 幸 福 的 人。//
```

而不是在词组中间断开：

```text
从 明 天 起，/ 做 一 个 幸
福 的 人。//
```

## 实现位置

主要修改：

```text
app/src/components/MapSvg.tsx
```

核心函数：

```text
makeTokenLines()
findPreferredBreakIndex()
groupHasPunctuationBoundary()
groupHasPauseBoundary()
```

## 注意

本次只修改 SVG 图谱预览的自动换行逻辑，不改变 JSON Schema，也不改变 token 数据结构。标点仍存储在 `token.punct_after`，停顿仍存储在 `token.pause_after`。
