# 第七阶段 v7.15：导出编辑态清理

## 目标

修复在导出 PNG / SVG 时，编辑过程中的选中状态被一起导出的 bug。

## 修复内容

1. 导出前会克隆一份 SVG，而不是直接序列化当前编辑中的 SVG。
2. 克隆 SVG 中会移除 `data-export-hidden="true"` 的编辑态元素。
3. 当前选中 token 的黄色高亮框被标记为 `data-export-hidden="true"`，导出时不再出现。
4. 当前激活段落的编辑态背景 / 描边会在导出克隆中还原为普通段落样式。
5. `导出 SVG` 与 `导出 PNG` 共用同一套导出清理逻辑。

## 不影响的内容

- 图谱正式视觉元素不变。
- 点击文稿弹出浮动标注菜单的功能不变。
- JSON 数据结构不变。
- 预览中的选中高亮仍然保留，只是不进入导出文件。

## 技术说明

新增导出辅助函数：

- `prepareSvgForExport(svgElement)`
- `serializeSvgForExport(svgElement)`

导出 PNG 前会先调用 `serializeSvgForExport`，因此 Canvas 渲染的是“正式图谱版”SVG，而不是带编辑状态的实时预览 SVG。
