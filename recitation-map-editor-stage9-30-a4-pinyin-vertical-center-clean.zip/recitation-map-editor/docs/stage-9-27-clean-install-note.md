# Stage 9.27 · 清洁安装说明

本包已移除 `node_modules`、`dist`、`package-lock.json` 和构建缓存，避免 Vite 软链接损坏。

```bash
cd /Users/mcf/Desktop
rm -rf recitation-map-editor
unzip recitation-map-editor-stage9-27-a4-prosody-layout-order-fix-clean.zip
cd recitation-map-editor/app
npm install
npm run dev
```
