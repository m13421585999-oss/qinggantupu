# Stage 9.29 · 清洁安装说明

```bash
cd /Users/mcf/Desktop
rm -rf recitation-map-editor
unzip recitation-map-editor-stage9-29-a4-pinyin-text-prosody-polish-clean.zip
cd recitation-map-editor/app
npm install
npm run dev
```
