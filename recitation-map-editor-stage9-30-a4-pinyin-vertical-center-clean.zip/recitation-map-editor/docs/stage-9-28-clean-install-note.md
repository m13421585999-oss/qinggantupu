# Stage 9.28 · 清洁安装说明

本包已移除 `node_modules`、`dist`、`package-lock.json` 和构建缓存。

运行方式：

```bash
cd /Users/mcf/Desktop
rm -rf recitation-map-editor
unzip recitation-map-editor-stage9-28-a4-prosody-natural-curve-clean.zip
cd recitation-map-editor/app
npm install
npm run dev
```
