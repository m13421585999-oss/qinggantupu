# 朗诵情感图谱编辑器交互规则 v1

## 1. 文档目标

本文档定义“朗诵情感图谱编辑器”第一版 MVP 的交互规则。第一版核心目标是让用户稳定完成手动标注，并实时生成统一版式图谱。

第一版不做自由画布式编辑器，不做 AI 自动标注，不接 TTS。

## 2. 第一版用户目标

用户应该能够完成以下任务：

1. 输入 3 段文稿。
2. 自动拆分 token。
3. 自动生成拼音。
4. 手动修改拼音。
5. 选择一个字或多个字。
6. 给选中 token 设置重音。
7. 给重音 token 添加 ▲、○、——。
8. 给某个 token 后添加 ∨、/、//、///。
9. 给每段选择语势类型。
10. 预览图谱。
11. 导出 PNG。

## 3. 基本编辑原则

1. 所有标注必须绑定 token。
2. 用户不能自由拖拽所有符号。
3. 用户点击符号后，系统自动放入正确层。
4. 文稿层只显示正文、标点、停顿、换气、重音红字。
5. 延音线 —— 只显示在重音读法层。
6. 语势线第一版只用模板，不支持自由绘制。
7. 语势线层不显示正文短语。

## 4. 输入文稿流程

### 4.1 输入方式

第一版可以提供 3 个段落输入框：

- 01 安静开始
- 02 生活展开
- 03 日常温暖

每个输入框对应一个 segment。

### 4.2 自动拆 token

用户输入文稿后，系统按汉字拆分 token。

示例输入：

```text
从明天起，做一个幸福的人。
```

生成 tokens：

```text
从 / 明 / 天 / 起 / 做 / 一 / 个 / 幸 / 福 / 的 / 人
```

标点不作为独立 token，进入前一个 token 的 `punct_after`。

示例：

```json
{
  "text": "起",
  "punct_after": "，"
}
```

```json
{
  "text": "人",
  "punct_after": "。"
}
```

## 5. 自动生成拼音

拆分 token 后，系统自动生成 pinyin。

示例：

```json
{
  "text": "从",
  "pinyin": "cóng"
}
```

拼音必须允许人工修改。

多音字、轻声、变调由用户最终确认。例如“一”可以根据上下文改为 `yí`。

## 6. 选择 token

用户可以：

1. 单击选择一个字。
2. 拖选或 Shift 选择多个字。
3. 双击选择一个 display_group，后续可实现。

第一版可以先支持单字和多字选择，display_group 选择可作为增强项。

选中 token 后，显示浮动标注工具条。

## 7. 浮动标注工具条

工具条包含：

| 按钮 | 功能 |
|---|---|
| 设为重音 | 将选中 token 的 is_emphasis 设为 true |
| ▲ | 添加或移除 strong |
| ○ | 添加或移除 light |
| —— | 添加或移除 extend |
| ∨ | 切换 breath_after |
| / | 设置 pause_after 为 / |
| // | 设置 pause_after 为 // |
| /// | 设置 pause_after 为 /// |
| 清除停顿 | 设置 pause_after 为空字符串 |
| 清除标注 | 清除该 token 的重音、读法、换气、停顿 |

## 8. 重音交互规则

### 8.1 设置重音

用户点击“设为重音”后：

```json
"is_emphasis": true
```

如果没有选择具体读法，系统可以提示用户选择 ▲、○ 或 ——。

### 8.2 添加读法

点击 ▲：

```json
"emphasis_method": ["strong"]
```

点击 ○：

```json
"emphasis_method": ["light"]
```

点击 ——：

```json
"emphasis_method": ["light", "extend"]
```

如果 token 原本没有重音，点击任何重音读法按钮时，系统应自动设置：

```json
"is_emphasis": true
```

### 8.3 删除读法

再次点击已启用的读法，表示移除该读法。

如果移除后 `emphasis_method` 为空，则系统应自动设置：

```json
"is_emphasis": false
```

### 8.4 冲突限制

第一版不建议同一个字同时出现 strong 和 light。

如果用户在 strong 已启用时点击 light，系统可以自动替换为 light。

如果用户在 light 已启用时点击 strong，系统可以自动替换为 strong。

extend 可以和 strong 或 light 组合，但 Demo 只推荐 light + extend。

## 9. 换气交互规则

点击 ∨ 后，系统切换：

```json
"breath_after": true
```

再次点击则切换回：

```json
"breath_after": false
```

换气符号渲染在该字右上角。

用户不能把 ∨ 拖到任意位置。

## 10. 停顿交互规则

点击 /、//、/// 后，系统写入：

```json
"pause_after": "/"
```

或：

```json
"pause_after": "//"
```

或：

```json
"pause_after": "///"
```

同一个 token 后只能有一个停顿值。

如果 token 已有 `punct_after`，渲染顺序为：

```text
文字 + 标点 + 停顿
```

例如：

```text
起∨，/
人。//
```

## 11. 拼音修改规则

用户可以点击拼音进入编辑状态。

修改后写入 token.pinyin。

拼音修改不影响 token.text。

建议第一版保留“恢复自动拼音”按钮，但不是必需。

## 12. display_group 规则

第一版 token 中保留 display_group，用于排版时区分词组。

示例：

```json
{ "text": "幸", "display_group": "幸福" }
{ "text": "福", "display_group": "幸福" }
```

第一版可以先不提供复杂的 display_group 编辑界面，但渲染器可根据 display_group 控制词组间距。

## 13. 语势类型选择

每个 segment 提供语势类型选择：

- 波峰型
- 起潮型
- 落潮型

用户选择后，系统自动写入：

```json
"prosody_type": "波峰型"
```

并同步生成对应 `prosody_curve` 模板。

第一版不支持自由绘制语势线。

## 14. 语势线模板

### 14.1 波峰型

```json
{
  "type": "波峰型",
  "points": [
    { "x": 0.08, "y": 0.25 },
    { "x": 0.42, "y": 0.45 },
    { "x": 0.68, "y": 0.85 },
    { "x": 0.92, "y": 0.3 }
  ],
  "labels": ["低位", "中位", "高位", "下收"]
}
```

### 14.2 起潮型

```json
{
  "type": "起潮型",
  "points": [
    { "x": 0.08, "y": 0.25 },
    { "x": 0.48, "y": 0.5 },
    { "x": 0.92, "y": 0.82 }
  ],
  "labels": ["低位", "中位", "高位"]
}
```

### 14.3 落潮型

```json
{
  "type": "落潮型",
  "points": [
    { "x": 0.08, "y": 0.78 },
    { "x": 0.48, "y": 0.5 },
    { "x": 0.92, "y": 0.24 }
  ],
  "labels": ["中高位", "中位", "低位"]
}
```

## 15. 预览规则

编辑器应提供实时预览。

用户修改 token 后，预览区立即根据 JSON 重新渲染。

不要直接修改 SVG 视觉元素，再反推 JSON。正确方向是：

```text
用户操作 → 修改 JSON → 根据 JSON 重新渲染 SVG
```

## 16. 导出规则

第一版导出 PNG。

推荐流程：

```text
JSON → React/SVG 图谱 → SVG to PNG
```

第一版暂不做 PDF。PDF 可在后续阶段增加。

## 17. 校验规则

保存或导出前应校验：

1. 每个 token 有 text。
2. 每个 token 有 pinyin。
3. 非重音 token 的 emphasis_method 为空数组。
4. 重音 token 的 emphasis_method 至少有一个值。
5. emphasis_method 只能为 strong、light、extend。
6. pause_after 只能为 ""、"/"、"//"、"///"。
7. prosody_curve.points 每个点必须有 x 和 y。
8. x 和 y 必须在 0–1 之间。
9. segment 必须有 id 和 theme。
10. storyboard.segment_id 必须能找到对应 segment。

## 18. MVP 不做事项

第一版不做：

1. AI 自动标注。
2. TTS 生成。
3. PDF 导出。
4. 多人协作。
5. 账号系统。
6. 复杂素材库。
7. 自由画布式编辑。
8. 自由绘制语势线。
9. 变换音色。
10. 一字一顿。
11. 句尾语调箭头。
12. 波谷型、半起型。

## 19. 推荐开发顺序

1. 完成 docs 文件。
2. 完成 schema 校验。
3. 完成 demo JSON 渲染。
4. 完成静态 SVG 预览。
5. 完成 token 选择。
6. 完成浮动工具条。
7. 完成拼音编辑。
8. 完成语势类型选择。
9. 完成 PNG 导出。

不要反过来先做 UI 外观。第一版必须先保证数据结构稳定。
