# 第八阶段 v8.2：参考图标与左侧信息卡片优化

本阶段根据参考图继续美化 UI，但不修改数据结构和核心交互。

## 修改内容

1. 图谱层标签图标改为内联 SVG 线性图标，不再使用临时字符图标。
2. 图标风格参考用户提供的示例：拼音层为层叠图标，读法层为提示三角，文稿层为文档图标，语势层为上升趋势线。
3. 图标作为 SVG 元素直接绘制，导出 PNG/SVG 时保持清晰，不依赖外部图片资源。
4. 去除左侧插画占位展示区。
5. 左侧“节奏 / 语势”改成独立的小信息卡片，并保留点击编辑能力。
6. 不改变 AI 初稿生成、点击文稿标注、语势点编辑、导出 PNG/SVG 等功能。

## 设计说明

本版选择内联 SVG 图标，而不是生成图片图标，原因是：

- SVG 图标缩放不失真；
- 导出图谱时不会出现图片资源丢失；
- 后续可以通过 CSS 统一控制颜色；
- 更适合程序化图谱渲染。

## 运行方式

```bash
cd /Users/mcf/Desktop
rm -rf recitation-map-editor
unzip recitation-map-editor-stage8-2-reference-icons-meta-cards.zip
cd recitation-map-editor/app
npm install
npm run dev
```
