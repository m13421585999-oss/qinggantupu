# 第四阶段说明：React + TypeScript 正式工程骨架

## 目标

第四阶段的目标是把第三阶段的静态 HTML/JS MVP 升级为正式前端工程骨架，便于后续持续开发、组件拆分、状态管理、Schema 校验和导出能力扩展。

本阶段仍然不接后端、不做账号系统、不做多人协作、不接 TTS。

## 技术栈

- React
- TypeScript
- Vite
- SVG 渲染
- 结构化 JSON 状态
- 自定义基础校验器
- 预留 pinyin-pro 接入位置

## 已实现功能

1. 使用 React 组件重构编辑器界面。
2. 使用 TypeScript 定义 `RecitationMap`、`Segment`、`Token`、`ProsodyCurve` 等核心类型。
3. 保留三段 Demo 数据，并作为应用初始状态。
4. 支持段落切换。
5. 支持 token 级选择与 Shift 多选。
6. 支持修改单字拼音。
7. 支持设置/取消重音。
8. 支持重音读法：`strong`、`light`、`extend`。
9. 支持换气符号 `∨`。
10. 支持停顿符号 `/`、`//`、`///`。
11. 支持五档语势点编辑：低、中低、中、中高、高。
12. 语势点横轴按顺序自动分布。
13. 系统根据语势点自动识别：起潮型、落潮型、波峰型、自定义语势。
14. 支持撤销 / 重做。
15. 支持导入 / 导出 JSON。
16. 支持导出 SVG / PNG。
17. 支持基础数据校验。
18. 支持输入文稿后拆分为 token。

## 当前约束

1. 自动拼音目前使用 Demo 字典 fallback，尚未正式接入 `pinyin-pro`。
2. 校验器是基础业务校验，不是完整 JSON Schema runtime validator。
3. SVG 排版仍以 Demo 长文稿为目标，未做复杂换行与多页导出。
4. 语势线仍为系统自动曲线，不支持自由绘制。
5. 插画仍为占位。
6. 未实现素材库、TTS、PDF、AI 自动标注。

## 如何运行

```bash
cd app
npm install
npm run dev
```

构建：

```bash
npm run build
```

基础数据校验：

```bash
npm run validate:demo
```

## 第五阶段建议

第五阶段建议聚焦工程质量和真实生产能力：

1. 接入 `pinyin-pro`，完成自动拼音生成和多音字人工修正流程。
2. 引入正式 JSON Schema 校验库，例如 Ajv。
3. 优化中文排版：按词组、标点、停顿进行自适应换行。
4. 增加保存草稿和本地文件管理。
5. 增加导出尺寸设置：讲义版、长图版、课件版。
6. 为老师版和学员版增加显示选项。
