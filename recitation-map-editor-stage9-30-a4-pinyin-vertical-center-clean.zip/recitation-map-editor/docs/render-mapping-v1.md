# 朗诵情感图谱渲染映射表 v1

## 1. 文档目标

本文档说明 `demo-recitation-map.json` 中的数据如何映射为可视化图谱。第一版推荐使用 SVG 渲染，不建议使用图片生成模型生产正式图谱。

渲染目标是生成稳定、可读、可导出的课程讲义式图谱。

## 2. 总体渲染原则

1. 图谱由结构化 JSON 驱动。
2. 所有朗诵符号都从 token 字段渲染，不允许自由漂浮。
3. 拼音层、重音读法层、文稿层三层上下对齐。
4. 语势线层独立显示，不重复正文。
5. 文稿层不显示延音线。
6. 标点保留但视觉弱化，停顿符号才是朗诵节奏依据。
7. 语势线使用 SVG path 和 circle nodes 渲染。

## 3. 顶层结构映射

| JSON 字段 | 渲染区域 | 说明 |
|---|---|---|
| meta.title | 页面顶部主标题 | 例如《面朝大海，春暖花开》情感图谱 |
| global.text_type | 顶部信息栏 | 文稿类型 |
| global.overall_tone | 顶部信息栏 | 全局基调标签 |
| global.technique_summary | 顶部信息栏 | 表达技巧总结 |
| segments | 主体段落卡片 | 每个 segment 渲染为一张段落卡片 |
| legend | 底部图例 | 显示当前实际使用的标记 |
| storyboard | 底部故事三宫格 | 按 segment_id 对应各段故事 |

## 4. layout 映射

| 字段 | 用途 |
|---|---|
| layout.template | 选择整体布局模板。第一版为 vertical_demo_v1。 |
| layout.page_size | 选择导出页面比例。第一版为 long_poster。 |
| layout.theme | 选择视觉主题。第一版为 soft_ink_wash。 |
| layout.segment_count | 控制段落数量校验和布局密度。 |
| layout.show_storyboard | 是否显示底部故事宫格。 |
| layout.show_legend | 是否显示图例。 |

第一版不要把这些样式写死在组件中。组件应根据 layout 决定是否渲染对应区域。

## 5. segment 左侧信息区映射

每个 segment 左侧显示：

| JSON 字段 | 视觉内容 |
|---|---|
| segment.id | 段落编号，例如 01 |
| segment.theme | 段落主题，例如 安静开始 |
| segment.rhythm_type | 节奏型，例如 舒缓型 |
| segment.prosody_type | 语势型，例如 波峰型 |
| segment.story.image_prompt 或 image_url | 小插画或占位图 |

第一版如果没有 image_url，可以显示固定占位插画或基于 theme 的简洁图标。

## 6. render_options 映射

| 字段 | true 时 | false 时 |
|---|---|---|
| show_pinyin | 显示拼音层 | 隐藏拼音层 |
| show_emphasis_method_layer | 显示重音读法层 | 隐藏重音读法层 |
| show_prosody_curve | 显示语势线层 | 隐藏语势线层 |
| show_illustration | 显示小插画 | 隐藏小插画 |

该字段用于未来切换学员版、老师版、TTS 版。

## 7. token 到拼音层映射

| token 字段 | 渲染结果 |
|---|---|
| text | 决定该 token 的横向位置 |
| pinyin | 显示在该 token 正上方 |
| display_group | 可用于控制词组间距 |

拼音层只显示拼音，不显示重音符号和停顿符号。

示例：

```json
{ "text": "福", "pinyin": "fú" }
```

渲染为：

```text
fú
福
```

## 8. token 到重音读法层映射

| token 字段 | 条件 | 渲染结果 |
|---|---|---|
| is_emphasis | false | 不显示读法符号 |
| emphasis_method includes strong | true | 显示 ▲ |
| emphasis_method includes light | true | 显示 ○ |
| emphasis_method includes extend | true | 在读法符号后显示 —— |

组合规则：

| emphasis_method | 显示 |
|---|---|
| ["strong"] | ▲ |
| ["light"] | ○ |
| ["light", "extend"] | ○—— |
| ["strong", "extend"] | ▲——，预留，不建议 Demo 使用 |

重音读法层不显示文字、不显示拼音。

## 9. token 到文稿层映射

| token 字段 | 渲染结果 |
|---|---|
| text | 显示正文汉字 |
| is_emphasis=true | 汉字显示为朱红色 |
| is_emphasis=false | 汉字显示为黑色 |
| punct_after | 显示在该字后，视觉弱化 |
| breath_after=true | 在该字右上角显示绿色 ∨ |
| pause_after | 在标点后显示 /、// 或 /// |

文稿层拼接顺序：

```text
text + breath mark + punct_after + pause_after
```

其中 breath mark 视觉上显示在 text 的右上角，不是普通行内字符。

示例：

```json
{
  "text": "起",
  "punct_after": "，",
  "breath_after": true,
  "pause_after": "/"
}
```

视觉结果：

```text
起∨，/
```

示例：

```json
{
  "text": "人",
  "punct_after": "。",
  "breath_after": false,
  "pause_after": "//"
}
```

视觉结果：

```text
人。//
```

## 10. 标点视觉映射

标点从 `punct_after` 渲染。

建议视觉规则：

- 标点保留。
- 字号比正文略小或颜色略淡。
- 标点不决定停顿时长。
- 停顿时长和节奏只看 `pause_after`。

正确顺序：

```text
文字 + 标点 + 停顿
```

错误顺序：

```text
文字 + 停顿 + 标点
```

## 11. 换气符号映射

| token 字段 | 渲染结果 |
|---|---|
| breath_after=true | 在该字右上角显示 ∨ |
| breath_after=false | 不显示 ∨ |

建议样式：

- 颜色：绿色
- 字号：小于正文
- 位置：当前字右上角
- 层级：文稿层内部

换气符号不是独立 token。

## 12. 停顿符号映射

| pause_after | 渲染结果 |
|---|---|
| "" | 不显示 |
| "/" | 显示 / |
| "//" | 显示 // |
| "///" | 显示 /// |

MVP 如果 pause_after 是字符串，直接渲染字符串。

如果后续 pause_after 升级为对象：

```json
{
  "symbol": "/",
  "duration_ms": 350
}
```

则视觉仍显示 `symbol`，`duration_ms` 只用于 TTS 或播放控制。

## 13. 语势线映射

`prosody_curve.points` 映射为 SVG 曲线。

字段：

```json
{
  "x": 0.08,
  "y": 0.25
}
```

转换规则：

```text
svgX = curveAreaLeft + x * curveAreaWidth
svgY = curveAreaBottom - y * curveAreaHeight
```

注意：数据中的 y=0 表示低位，y=1 表示高位。SVG 坐标中 y 越大越靠下，所以需要反向转换。

建议渲染：

1. 先画低 / 中 / 高水平参考线。
2. 根据 points 生成平滑 path。
3. 在每个 point 位置画圆形节点。
4. 在节点附近显示 labels。

第一版可以使用三次贝塞尔曲线，也可以先使用折线 + smooth curve。重点是稳定，不是复杂拟声。

## 14. 三种语势模板映射

### 14.1 波峰型

数据：

```json
{
  "type": "波峰型",
  "points": [
    { "x": 0.08, "y": 0.25 },
    { "x": 0.42, "y": 0.45 },
    { "x": 0.68, "y": 0.85 },
    { "x": 0.92, "y": 0.3 }
  ],
  "labels": ["低位", "中位", "高位", "下收"]
}
```

视觉：低位 → 中位 → 高位 → 下收。

### 14.2 起潮型

数据：

```json
{
  "type": "起潮型",
  "points": [
    { "x": 0.08, "y": 0.25 },
    { "x": 0.48, "y": 0.5 },
    { "x": 0.92, "y": 0.82 }
  ],
  "labels": ["低位", "中位", "高位"]
}
```

视觉：低位 → 中位 → 高位。

### 14.3 落潮型

数据：

```json
{
  "type": "落潮型",
  "points": [
    { "x": 0.08, "y": 0.78 },
    { "x": 0.48, "y": 0.5 },
    { "x": 0.92, "y": 0.24 }
  ],
  "labels": ["中高位", "中位", "低位"]
}
```

视觉：中高位 → 中位 → 低位。

## 15. 图例映射

`legend.text_marks` 显示文稿标记：

- ∨ 换气
- / 小停
- // 中停
- /// 长停

`legend.emphasis_methods` 显示重音读法：

- ▲ 加大音量
- ○ 重音轻读
- —— 拖长读音

`legend.prosody_types` 显示语势类型：

- 波峰型：低 → 高 → 低
- 起潮型：低 → 中 → 高
- 落潮型：中高 → 中 → 低

图例只显示第一版实际使用的内容，不加入未启用功能。

## 16. storyboard 映射

`storyboard` 渲染为底部三宫格。

| 字段 | 渲染结果 |
|---|---|
| segment_id | 与段落对应 |
| title | 宫格标题 |
| description | 宫格说明 |
| image_prompt | 可用于生成插画或占位图说明 |
| image_url | 有值时显示图片，无值时显示占位图 |

storyboard 和 segment.story 内容可以保持一致。segment.story 用于段落卡片局部展示，storyboard 用于底部整体展示。

## 17. 推荐 SVG 层级

建议 SVG / DOM 层级：

```text
MapCanvas
  Header
  GlobalInfoBar
  SegmentList
    SegmentCard
      SegmentMetaPanel
      SegmentNotationPanel
        PinyinLayer
        EmphasisMethodLayer
        TextLayer
        ProsodyCurveLayer
  Legend
  Storyboard
```

## 18. 禁止映射

以下做法禁止出现在第一版：

1. 把 emphasis_method 符号渲染到文稿层。
2. 把拼音渲染到重音读法层。
3. 把延音线 —— 渲染到文稿层。
4. 在语势线层重复正文短语。
5. 用自由拖拽坐标存储停顿、换气、重音。
6. 用颜色区分情感重音、画面重音、动作重音、逻辑重音。
7. 第一版显示句尾语调箭头。
8. 让图片生成模型决定正式图谱排版。
